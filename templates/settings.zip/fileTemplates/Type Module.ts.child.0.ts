#set($PASCAL_CASE_NAME = ${StringUtils.removeAndHump(${NAME}, "-")})

export { $PASCAL_CASE_NAME } from "./$NAME"