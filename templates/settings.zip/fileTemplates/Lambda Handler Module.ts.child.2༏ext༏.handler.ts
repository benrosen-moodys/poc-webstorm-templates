#set($FIRST = $NAME.substring(0, 1).toUpperCase())
#set($REST = $NAME.substring(1))
#set($CAPITALIZED_NAME = ${FIRST} + ${REST})
#set($EVENT_NAME = "Incoming${CAPITALIZED_NAME}Event")
#set($HANDLER_NAME = "${NAME}Handler")

import {
  generateHttpError,
  HttpErrorStatusCode,
  HttpSuccessStatusCode,
} from "@moodys/mdc-toolbox.back-end.lambda-core";
import { $EVENT_NAME } from "./${NAME}.types";

export const $HANDLER_NAME = async (
  event: $EVENT_NAME
) => {
    //
};