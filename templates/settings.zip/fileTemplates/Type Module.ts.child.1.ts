#set($PASCAL_CASE_NAME = ${StringUtils.removeAndHump(${NAME}, "-")})

import { $PASCAL_CASE_NAME } from "./$NAME"

/**
 * Return `true` if the given value (of `unknown` type) is of type {@link $PASCAL_CASE_NAME}.
 * Otherwise, return `false`.
 * @param value A value of `unknown` type.
 */
export const is$PASCAL_CASE_NAME = (value: unknown): value is $PASCAL_CASE_NAME => {
  throw new Error("Not implemented.");
};