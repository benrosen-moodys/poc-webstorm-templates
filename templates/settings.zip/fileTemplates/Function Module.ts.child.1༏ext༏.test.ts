#set($PASCAL_CASE_NAME = ${StringUtils.removeAndHump(${NAME}, "-")})
#set($FIRST = $PASCAL_CASE_NAME.substring(0, 1).toLowerCase())
#set($REST = $PASCAL_CASE_NAME.substring(1))
#set($CAMEL_CASE_NAME = ${FIRST} + ${REST})

import { $CAMEL_CASE_NAME } from "./$NAME"

const cases: [
    Parameters<typeof $CAMEL_CASE_NAME>[0], 
    ReturnType<typeof $CAMEL_CASE_NAME>
][] = []

describe("The $CAMEL_CASE_NAME function", () => {
    test.each(cases)(
      "should return the expected value for the given valid input",
      (validExample, expectedResult) => {
        const result = $CAMEL_CASE_NAME(validExample);
        
        expect(result).toStrictEqual(expectedResult);
      }
    )
});