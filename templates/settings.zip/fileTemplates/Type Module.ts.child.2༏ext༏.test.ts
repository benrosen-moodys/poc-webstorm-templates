#set($PASCAL_CASE_NAME = ${StringUtils.removeAndHump(${NAME}, "-")})

import { is$PASCAL_CASE_NAME } from "./is-$NAME"

const validExamples = []

const invalidExamples = []

describe("The is$PASCAL_CASE_NAME type-guard function", () => {
  describe("should return `true`", () => {
    test.each(validExamples)(
      "when the given value, %j, is of type $PASCAL_CASE_NAME",
      (validExample) => {
        const result = is$PASCAL_CASE_NAME(validExample);
        
        expect(result).toStrictEqual(true);
      }
    );
  });
  
  describe("should return `false`", () => {
    test.each(invalidExamples)(
      "when the given value, %j, is NOT of type $PASCAL_CASE_NAME",
      (invalidExample) => {
        const result = is$PASCAL_CASE_NAME(invalidExample);
        
        expect(result).toStrictEqual(false);
      }
    );
  });
});