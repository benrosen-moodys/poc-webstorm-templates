#set($HANDLER_NAME = "${NAME}Handler")

import { $HANDLER_NAME } from "./${NAME}.handler";

describe("The $HANDLER_NAME function", () => {
    describe("should return a 2xx status code", () => {
        test("when", () => {
            expect(true).toStrictEqual(false);
        }
    });
    
    describe("should return a 4xx status code", () => {
        test("when", () => {
            expect(true).toStrictEqual(false);
        }
    });
    
    describe("should return a 5xx status code", () => {
        test("when", () => {
            expect(true).toStrictEqual(false);
        }
    });
});