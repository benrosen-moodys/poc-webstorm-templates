#set($FIRST = $NAME.substring(0, 1).toUpperCase())
#set($REST = $NAME.substring(1))
#set($CAPITALIZED_NAME = ${FIRST} + ${REST})
#set($EVENT_NAME = "Incoming${CAPITALIZED_NAME}Event")

export type $EVENT_NAME = unknown;