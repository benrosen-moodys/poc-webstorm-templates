#set($PASCAL_CASE_NAME = ${StringUtils.removeAndHump(${NAME}, "-")})
#set($FIRST = $PASCAL_CASE_NAME.substring(0, 1).toLowerCase())
#set($REST = $PASCAL_CASE_NAME.substring(1))
#set($CAMEL_CASE_NAME = ${FIRST} + ${REST})

export const $CAMEL_CASE_NAME = (props: {}) => {
  //
}