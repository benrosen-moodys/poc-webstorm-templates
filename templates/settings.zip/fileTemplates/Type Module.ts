/**
 * 
 */
export type ${StringUtils.removeAndHump(${NAME}, "-")} = unknown;