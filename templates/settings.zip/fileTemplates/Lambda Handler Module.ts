#set($HANDLER_NAME = "${NAME}Handler")

/* istanbul ignore file */
import { generateLambdaHandler } from "@moodys/mdc-toolbox.back-end.lambda-core";
import { getLambdaInfo } from "../../config/lambdaInfo";
import { loggerOptions } from "../../config/loggerOptions";
import { fetchConfigSchema } from "../../config/fetchConfig.schema";
import { $HANDLER_NAME } from "./${NAME}.handler";

export const handler = generateLambdaHandler($HANDLER_NAME, {
  lambdaInfo: getLambdaInfo("$NAME"),
  loggerOptions: loggerOptions,
  disableMiddlewareResponseHeaders: true,
  fetchConfig: {
    schemas: [fetchConfigSchema.SQL_USD],
  },
});